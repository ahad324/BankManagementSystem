import { Client, Databases, ID, Query } from "appwrite";
import argon2 from 'argon2';

const PROJECT_ID = "666b2d4b002579cc85ea";
const DATABASE_ID = "666b30e2001dda7640db";
const COLLECTION_ID_USERS = "666caf8d003db35e8a54";
const COLLECTION_ID_TRANSACTIONS = "666dd34e001b637f302a";
const COLLECTION_ID_PENDING_ACCOUNTS = "666efd860025ac6a9e7c";
const COLLECTION_ID_ADMIN = "ADMIN";

const client = new Client()
  .setEndpoint("https://cloud.appwrite.io/v1")
  .setProject(PROJECT_ID);

const databases = new Databases(client);

const args = process.argv.slice(2);
const command = args[0];

// <=============== FUNCTIONS RELATED TO FETCHING ACCOUNTS =====================>
if (command === "FetchAccounts") {
  FetchAccounts();
} else if (command === "FetchPendingAccounts") {
  FetchPendingAccounts();
}
async function FetchAccounts() {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_USERS,
      []
    );
    for (let i = 0; i < response.total; i++) {
      const user = response.documents[i];
      const { username, email, accountType, balance, CNIC } = user;

      console.log(
        `${username} ${email} ${accountType} ${balance} ${CNIC}`
      );
    }
  } catch (error) {
    console.error("Error:", error);
  }
}

async function FetchPendingAccounts() {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_PENDING_ACCOUNTS,
      []
    );
    for (let i = 0; i < response.total; i++) {
      const user = response.documents[i];
      const { username, email, accountType, CNIC } = user;

      console.log(`${username} ${email} ${accountType}  ${CNIC}`);
    }
  } catch (error) {
    console.error("Error:", error);
  }
}

if (command === "MoveToAccounts") {
  const cnic = args[1];
  MoveToAccounts(cnic);
}
async function MoveToAccounts(cnic) {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_PENDING_ACCOUNTS,
      [Query.equal("CNIC", cnic)]
    );
    const { username, email, accountType, balance, CNIC, password } = response.documents[0];
    let payload = {
      username: username,
      password: password,
      email: email,
      accountType: accountType,
      balance: 0,
      CNIC: CNIC,
    };
    // Create a new user
    const promise = await databases.createDocument(
      DATABASE_ID,
      COLLECTION_ID_USERS,
      ID.unique(),
      payload
    );
    DeleteAccount(cnic, COLLECTION_ID_PENDING_ACCOUNTS);
    console.log("ACCOUNT MOVED TO ACCOUNTS SUCCESSFULLY");
  } catch (error) {
    console.error("Error:", error);
  }
}

// <=============== ADMIN AUTHENTICATION =====================>
if (command === "AdminLogin") {
  const username = args[1];
  const password = args[2];
  AdminLogin(username, password);
}
async function AdminLogin(username, password) {
  try {

    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_ADMIN,
      []
    );
    if (response.documents[0].username === username) {
      const isPasswordValid = await argon2.verify(response.documents[0].password, password);
      if (isPasswordValid) {
        console.log("SUCCESS");
      }
    }
  } catch (error) {
    console.log("Error Occurred");
  }
};
// <=============== FUNCTIONS RELATED TO USER REGISTRATION =====================>

if (command === "Register") {
  const username = args[1];
  const password = args[2];
  const email = args[3];
  const accountType = args[4];
  const cnic = args[5];
  Register(username, password, email, accountType, cnic);
}
async function Register(username, pass, email, accType, cnic) {
  try {
    const hashedPassword = await argon2.hash(pass);
    let payload = {
      username: username,
      password: hashedPassword,
      email: email,
      accountType: accType.toUpperCase() === "S" ? "Savings" : "Current",
      balance: 0,
      CNIC: cnic,
    };
    // Create a new user
    const promise = await databases.createDocument(
      DATABASE_ID,
      COLLECTION_ID_PENDING_ACCOUNTS,
      ID.unique(),
      payload
    );
    console.log("USER CREATED SUCCESSFULLY");
  } catch (error) {
    console.error("Error:", error);
  }
}

// <=============== FUNCTIONS RELATED TO USER LOGIN =====================>
if (command === "UserLogin") {
  const cnic = args[1];
  const password = args[2];
  UserLogin(cnic, password);
}
async function UserLogin(cnic, password) {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_USERS,
      [Query.equal("CNIC", cnic)]
    );
    if (response.documents[0].CNIC === cnic) {
      const isPasswordValid = await argon2.verify(response.documents[0].password, password);
      if (isPasswordValid) {
        console.log("SUCCESS");
      } else {
        console.log("Incorrect password");
      }
    }
  } catch (error) {
    console.log("Error Occurred");
  }
}
// <=============== FUNCTION RELATED TO BALANCE UPDATES =====================>
if (command === "BalanceUpdate") {
  const cnic = args[1];
  const newBalance = args[2];
  UpdateUserBalance(cnic, newBalance);
}
async function UpdateUserBalance(cnic, newBalance) {
  let response = await databases.listDocuments(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    [Query.equal("CNIC", cnic)]
  );
  let documentID = response.documents[0].$id;
  // console.log(documentID);

  let promise = await databases.updateDocument(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    documentID,
    { balance: parseFloat(newBalance) }
  );
}

if (command === "ChangeUserPassword") {
  const cnic = args[1];
  const newPasword = args[2];
  ChangeUserPassword(cnic, newPasword);
}
async function ChangeUserPassword(cnic, newPasword) {
  const hashedPassword = await argon2.hash(newPasword);
  let response = await databases.listDocuments(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    [Query.equal("CNIC", cnic)]
  );
  let documentID = response.documents[0].$id;

  let promise = await databases.updateDocument(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    documentID,
    { password: hashedPassword }
  );
}

if (command === "ChangeUserUsername") {
  const cnic = args[1];
  const newUsername = args[2];
  ChangeUserUsername(cnic, newUsername);
}
async function ChangeUserUsername(cnic, newUsername) {
  let response = await databases.listDocuments(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    [Query.equal("CNIC", cnic)]
  );
  let documentID = response.documents[0].$id;
  // console.log(documentID);

  let promise = await databases.updateDocument(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    documentID,
    { username: newUsername }
  );
  console.log("USERNAME_UPDATED");
}

if (command === "LogTransaction") {
  const cnic = args[1];
  const timestamp = args[2];
  const type = args[3];
  const amount = parseFloat(args[4]);
  if (args[5]) {
    const ToORFromCNIC = args[5];
    logTransaction(cnic, timestamp, type, amount, ToORFromCNIC);
  } else {
    logTransaction(cnic, timestamp, type, amount);
  }
}

async function logTransaction(cnic, timestamp, type, amount, ToORFromCNIC) {
  try {
    const payload = {
      cnic: cnic,
      timestamp: timestamp,
      type: type,
      amount: amount,
      ToORFromCNIC: ToORFromCNIC,
    };
    await databases.createDocument(
      DATABASE_ID,
      COLLECTION_ID_TRANSACTIONS,
      ID.unique(),
      payload
    );
    console.log("TRANSACTION_LOGGED");
  } catch (error) {
    console.error(error);
  }
}

if (command === "FetchTransactions") {
  const cnic = args[1];
  fetchTransactions(cnic);
}

async function fetchTransactions(cnic) {
  try {
    const response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_TRANSACTIONS,
      [Query.equal("cnic", cnic)]
    );
    // console.log(JSON.stringify(response.documents));
    let transactions = response.documents.map((doc) => ({
      CNIC: doc.cnic,
      Timestamp: doc.timestamp,
      Type: doc.type,
      Amount: `$${doc.amount}`,
      "From(CNIC)": doc.type === "Received" && doc.ToORFromCNIC ? doc.ToORFromCNIC : "",
      "To(CNIC)": doc.type === "Transfer" && doc.ToORFromCNIC ? doc.ToORFromCNIC : ""
    }));
    // Check if any "From(CNIC)" or "To(CNIC)" fields have values
    const includeFrom = transactions.some(transaction => transaction["From(CNIC)"]);
    const includeTo = transactions.some(transaction => transaction["To(CNIC)"]);

    // Filter out empty fields
    transactions = transactions.map(transaction => {
      const filteredTransaction = { ...transaction };
      if (!includeFrom) delete filteredTransaction["From(CNIC)"];
      if (!includeTo) delete filteredTransaction["To(CNIC)"];
      return filteredTransaction;
    });
    // Calculate column widths
    const columns = ["CNIC", "Timestamp", "Type", "Amount"];
    if (includeFrom) columns.push("From(CNIC)");
    if (includeTo) columns.push("To(CNIC)");

    const colWidths = columns.map(col => col.length);
    transactions.forEach(transaction => {
      columns.forEach((col, i) => {
        colWidths[i] = Math.max(colWidths[i], (transaction[col] || "").toString().length);
      });
    });

    // Create the table header
    const separator = colWidths.map(width => '-'.repeat(width + 2.1)).join('+');
    const header = columns.map((col, i) => col.padEnd(colWidths[i])).join(' | ');

    // Print the table
    console.log(`\t\t\t${separator}`);
    console.log(`\t\t\t| ${header} |`);
    console.log(`\t\t\t${separator}`);
    transactions.forEach(transaction => {
      const row = columns.map((col, i) => (transaction[col] || "").toString().padEnd(colWidths[i])).join(' | ');
      console.log(`\t\t\t| ${row} |`);
    });
    console.log(`\t\t\t${separator}`);
  } catch (error) {
    console.error(error);
  }
}
if (command === "DeleteAccount") {
  const cnic = args[1];
  DeleteAccount(cnic, COLLECTION_ID_USERS);
}
async function DeleteAccount(cnic, CollectionID) {
  try {
    let response = await databases.listDocuments(DATABASE_ID, CollectionID, [
      Query.equal("CNIC", cnic),
    ]);
    let documentID = response.documents[0].$id;

    let promise = await databases.deleteDocument(
      DATABASE_ID,
      CollectionID,
      documentID
    );
    console.log("ACCOUNT_DELETED");
  } catch (error) {
    console.error("Error:", error);
  }
}
