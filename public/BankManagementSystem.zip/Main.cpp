#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <fstream>
#include <cstdlib> // for system("cls")
#include <conio.h> // for _getch()
#include <regex>
#include <ctime>
#include <windows.h>

using namespace std;

const int SuccessMessagesColorCode = 10;
const int WaitingMessagesColorCode = 11;
const int ErrorMessagesColorCode = 12;
const int DefaultColorCode = 1;

void setConsoleForegroundColor(int colorCode)
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, colorCode);
}
void PrintColoredText(const string &text, int color)
{
    setConsoleForegroundColor(color);
    cout << "\t\t\t" << text << endl;
    setConsoleForegroundColor(DefaultColorCode); // Reset to default color
}
// <==================== Checking and Installing Dependencies   =================>
bool checkDependency(const string &command, const string &name)
{
    PrintColoredText("Checking if " + name + " is installed or not...", WaitingMessagesColorCode);
    bool isInstalled = system(command.c_str()) == 0;
    if (isInstalled)
    {
        PrintColoredText(name + " is installed.", SuccessMessagesColorCode);
    }
    else
    {
        PrintColoredText(name + " is not installed.", ErrorMessagesColorCode);
    }
    return isInstalled;
}

void installDependency(const string &installCommand, const string &name)
{
    PrintColoredText("Installing " + name + "...", WaitingMessagesColorCode);
    system(installCommand.c_str());
}
void createPackageJson()
{
    ofstream packageFile("package.json");
    packageFile << R"({
    "type": "module",
    "dependencies": {
        "appwrite": "^15.0.0"
    }
})";
    packageFile.close();
}

bool checkAndInstallDependencies()
{
    bool npmInstalled = checkDependency("npm -v > nul 2>&1", "npm");
    bool nodeInstalled = checkDependency("node -v > nul 2>&1", "Node.js");
    bool appwriteInstalled = checkDependency("npm list appwrite > nul 2>&1", "Appwrite");

    if (!npmInstalled)
    {
        PrintColoredText("npm is required to install other dependencies. Please install npm manually.", ErrorMessagesColorCode);
        return false;
    }

    if (!nodeInstalled || !appwriteInstalled)
    {
        char choice;
        cout << "One or more dependencies are missing. Would you like to install them? (y/n): ";
        cin >> choice;

        if (choice == 'y' || choice == 'Y')
        {
            if (!nodeInstalled)
            {
                installDependency("npm install -g node", "Node.js");
            }
            if (!appwriteInstalled)
            {
                installDependency("npm install -g appwrite", "Appwrite");
            }
            return true;
        }
        else
        {
            PrintColoredText("Dependencies are required to run this program. Exiting...", ErrorMessagesColorCode);
            return false;
        }
    }

    PrintColoredText("All dependencies are installed.", SuccessMessagesColorCode);
    return true;
}
string callJavaScript(const string &command)
{
    string cmd = "node Server.js " + command + " > output.txt";
    system(cmd.c_str());

    ifstream file("output.txt");
    string result;
    getline(file, result);
    file.close();

    ofstream clearFile("output.txt", ios::trunc);
    clearFile.close();
    return result;
}
// FetchAllUsersFromJavaScript
string FetchAllLargeDataFromJavaScript(const string &command)
{
    string cmd = "node Server.js " + command + " > output.txt";
    system(cmd.c_str());

    ifstream file("output.txt");
    stringstream buffer;
    buffer << file.rdbuf();
    string result = buffer.str();
    file.close();

    ofstream clearFile("output.txt", ios::trunc);
    clearFile.close();

    return result;
}
// Struct to represent a transaction
struct Transaction
{
    string timestamp;
    string username;
    string type; // "Deposit", "Withdrawal" or "Transfer"
    double amount;
};

// Base class to represent a bank account
class Account
{
protected:
    string cnic;
    string username;
    string password;
    string email;
    double balance;
    vector<Transaction> transactions; // Transaction history

public:
    string getCurrentTimestamp()
    {
        time_t now = time(0);
        tm *ltm = localtime(&now);
        stringstream ss;
        ss << 1900 + ltm->tm_year << "-"
           << 1 + ltm->tm_mon << "-"
           << ltm->tm_mday << "_"
           << ltm->tm_hour << ":"
           << ltm->tm_min << ":"
           << ltm->tm_sec;
        return ss.str();
    }

    Account(string _cnic, string _username, string _password, string _email, double _balance = 0)
        : cnic(_cnic), username(_username), password(_password), email(_email), balance(_balance) {}

    virtual ~Account() {}

    string getUsername() const { return username; }

    string getCNIC() const { return cnic; }
    string getPassword() const { return password; }

    string getEmail() const { return email; }

    double getBalance() const { return balance; }

    void logTransaction(const string &cnic, const string &timestamp, const string &type, double amount, const string &recipientCnic = "")
    {
        // Debug statement for testing (remove this after confirming the method is called)
        cout << "logTransaction called with Type: " << type << " Amount: " << amount << endl;

        string command = "LogTransaction " + cnic + " " + timestamp + " " + type + " " + to_string(amount);
        if (!recipientCnic.empty())
        {
            command += " " + recipientCnic;
        }
        string result = callJavaScript(command);
        cout << result << endl;
    }

    void deposit(double amount, string type = "")
    {
        balance += amount;
        string timestamp = getCurrentTimestamp();
        transactions.push_back({timestamp, username, type, amount});
        if (type != "Received" && type != "Transfer")
        {
            logTransaction(cnic, timestamp, type, amount); // Log transaction
        }
        UpdateBalanceInBackend();
    }

    bool withdraw(double amount, string type)
    {
        if (balance >= amount)
        {
            balance -= amount;
            string timestamp = getCurrentTimestamp();
            transactions.push_back({timestamp, username, type, amount});
            if (type != "Received" && type != "Transfer")
            {
                logTransaction(cnic, timestamp, type, amount); // Log transaction
            }
            UpdateBalanceInBackend();
            return true;
        }
        return false;
    }
    void UpdateBalanceInBackend()
    {
        string command = "BalanceUpdate " + cnic + " " + to_string(balance);
        string result = callJavaScript(command);
        cout << result << endl;
    }

    void changeUsername(string new_username)
    {
        username = new_username;
    }

    // Function to display user menu
    virtual void displayMenu()
    {
        cout << "Welcome, " << getUsername() << "!" << endl;
        cout << "Your balance is: $" << getBalance() << endl;
        cout << "1. Deposit\n2. Withdraw\n3. Change Password\n4. Change Username\n5. View Transaction History\n6. Transfer Money\n7. Logout\n";
    }

    void viewTransactionHistory(string cnic) const
    {
        string command = "FetchTransactions " + cnic;
        string result = FetchAllLargeDataFromJavaScript(command);

        cout << "Transaction History for User : " << getUsername() << endl;

        if (result.empty())
        {
            cout << "No transactions found.\n";
        }
        else
        {
            cout << result << endl;
        }

        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }

    virtual string getAccountType() const = 0;
};

// Derived class for Savings Account
class SavingsAccount : public Account
{
public:
    SavingsAccount(string _cnic, string _username, string _password, string _email, double _balance = 0)
        : Account(_cnic, _username, _password, _email, _balance) {}

    string getAccountType() const override
    {
        return "Savings";
    }
};

// Derived class for Current Account
class CurrentAccount : public Account
{
public:
    CurrentAccount(string _cnic, string _username, string _password, string _email, double _balance = 0)
        : Account(_cnic, _username, _password, _email, _balance) {}

    string getAccountType() const override
    {
        return "Current";
    }
};

// Class to manage accounts
class Bank
{
private:
    vector<Account *> accounts;
    vector<Account *> pendingAccounts;

public:
    Bank()
    {
        loadAccountsFromBackend();
        loadPendingAccountsFromBackend();
    }

    ~Bank()
    {
        for (auto account : accounts)
        {
            delete account;
        }
        for (auto account : pendingAccounts)
        {
            delete account;
        }
    }
    void loadAccountsFromBackend()
    {
        string command = "FetchAccounts"; // Command to fetch all user details
        string result = FetchAllLargeDataFromJavaScript(command);

        if (result.empty())
        {
            PrintColoredText("Failed to fetch accounts from the backend.Make sure you have a strong internet connection.", ErrorMessagesColorCode);
            cout << "Press any key to exit...";
            _getch(); // Wait for user input
            exit(0);  // Exit the program
        }
        // Split the result string into lines
        stringstream ss(result);
        string line;

        while (getline(ss, line))
        {
            if (line.empty())
                continue; // Skip empty lines

            // Split each line into account details
            stringstream lineStream(line);
            string username, email, accountType, cnic, password;
            double balance;

            lineStream >> username >> email >> accountType >> balance >> cnic >> password;

            // Create account objects based on the account type
            Account *account = nullptr;
            if (accountType == "Savings")
            {
                account = new SavingsAccount(cnic, username, password, email, balance);
            }
            else
            {
                account = new CurrentAccount(cnic, username, password, email, balance);
            }

            // Add the account object to the accounts vector
            accounts.push_back(account);
        }

        // Displaying the fetched result for verification
        // cout << "Press any key to continue...";
        // _getch();
    }

    void loadPendingAccountsFromBackend()
    {
        string command = "FetchPendingAccounts"; // Command to fetch all user details
        string result = FetchAllLargeDataFromJavaScript(command);

        if (result.empty())
        {
            PrintColoredText("Failed to fetch pending accounts from the backend.Make sure you have a strong internet connection.", ErrorMessagesColorCode);
            cout << "Press any key to exit...";
            _getch(); // Wait for user input
            exit(0);  // Exit the program
        }
        // Split the result string into lines
        stringstream ss(result);
        string line;

        while (getline(ss, line))
        {
            if (line.empty())
                continue; // Skip empty lines

            // Split each line into account details
            stringstream lineStream(line);
            string username, email, accountType, cnic, password;
            double balance;

            lineStream >> username >> email >> accountType >> cnic >> password;

            // Create account objects based on the account type
            Account *pendingaccount = nullptr;
            if (accountType == "Savings")
            {
                pendingaccount = new SavingsAccount(cnic, username, password, email, 0);
                ;
            }
            else
            {
                pendingaccount = new CurrentAccount(cnic, username, password, email, 0);
            }

            // Add the account object to the accounts vector
            pendingAccounts.push_back(pendingaccount);
        }

        // Displaying the fetched result for verification
        // cout << "Press any key to continue...";
        // _getch();
    }
    bool authenticateAdmin(string username, string password)
    {
        return (username == "admin" && password == "admin");
    }

    Account *authenticateUser(string cnic, string password)
    {
        // Search for the user in the loaded accounts vector
        for (auto account : accounts)
        {
            if (account->getCNIC() == cnic && account->getPassword() == password)
            {
                // If CNIC and password match, return the account object
                return account;
            }
        }

        // If user not found or password doesn't match, return nullptr
        return nullptr;
    }
    void createAccount(Account *account, bool isPending = false)
    {
        if (isPending)
        {
            pendingAccounts.push_back(account);
            PrintColoredText("\n\nAccount created successfully. Pending admin approval.", SuccessMessagesColorCode);
        }
        else
        {
            accounts.push_back(account);
            PrintColoredText("Account approved and created successfully.", SuccessMessagesColorCode);
        }
        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }

    void approvePendingAccounts()
    {
        if (pendingAccounts.empty())
        {
            cout << "No pending accounts to approve.\n";
        }
        else
        {
            cout << "Pending Accounts:\n";
            for (size_t i = 0; i < pendingAccounts.size(); ++i)
            {
                cout << i + 1 << ". CNIC: " << pendingAccounts[i]->getCNIC() << ", Username: " << pendingAccounts[i]->getUsername() << endl;
            }

            int choice;
            cout << "Enter the number of the account to approve (0 to exit): ";
            cin >> choice;

            if (choice > 0 && choice <= pendingAccounts.size())
            {
                string username = pendingAccounts[choice - 1]->getUsername();
                string cnic = pendingAccounts[choice - 1]->getCNIC();
                string email = pendingAccounts[choice - 1]->getEmail();
                string password = pendingAccounts[choice - 1]->getPassword();
                string accountType = pendingAccounts[choice - 1]->getAccountType();

                string command = "MoveToAccounts " + username + " " + password + " " + email + " " + accountType + " " + cnic;
                string result = callJavaScript(command);

                cout << "JavaScript command result: " << result << endl;

                if (result == "ACCOUNT MOVED TO ACCOUNTS SUCCESSFULLY")
                {
                    // Move the account from pendingAccounts to accounts
                    accounts.push_back(pendingAccounts[choice - 1]);
                    pendingAccounts.erase(pendingAccounts.begin() + choice - 1);
                    PrintColoredText("Account approved and moved to main accounts.", SuccessMessagesColorCode);
                }
                else
                {
                    PrintColoredText("Failed to move user to main accounts.", ErrorMessagesColorCode);
                }
            }
        }
        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }

    void changeUserPassword(string cnic, string new_password)
    {
        string command = "ChangeUserPassword " + cnic + " " + new_password;
        string result = callJavaScript(command);
        // cout << "User not found.\n";
        cout << "Password Changed Successfully\n";
        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }
    void changeUserUsername(string cnic, string new_username, Account *account)
    {
        string command = "ChangeUserUsername " + cnic + " " + new_username;
        string result = callJavaScript(command);

        if (result == "USERNAME_UPDATED")
        {
            account->changeUsername(new_username);
            PrintColoredText("Username changed successfully.", SuccessMessagesColorCode);
        }
        else
        {
            PrintColoredText("Username change failed.", ErrorMessagesColorCode);
        }
        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }

    void viewAllAccounts()
    {
        if (accounts.empty())
        {
            cout << "No accounts found.\n";
        }
        else
        {
            cout << "All Accounts:\n";
            for (const auto &account : accounts)
            {
                cout << "CNIC: " << account->getCNIC() << ", Username: " << account->getUsername()
                     << ", Email: " << account->getEmail() << ", Balance: $" << account->getBalance()
                     << ", Type: " << account->getAccountType() << endl;
            }
        }
        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }

    void removeAccount()
    {
        if (accounts.empty())
        {
            cout << "No accounts to remove.\n";
        }
        else
        {
            cout << "Accounts:\n";
            for (size_t i = 0; i < accounts.size(); ++i)
            {
                cout << i + 1 << ". CNIC: " << accounts[i]->getCNIC() << ", Username: " << accounts[i]->getUsername()
                     << ", Email: " << accounts[i]->getEmail() << ", Balance: $" << accounts[i]->getBalance() << endl;
            }

            int choice;
            cout << "Enter the number of the account to remove (0 to exit): ";
            cin >> choice;

            if (choice > 0 && choice <= accounts.size())
            {
                string command = "DeleteAccount " + accounts[choice - 1]->getCNIC();
                string result = callJavaScript(command);
                if (result == "ACCOUNT_DELETED")
                {
                    delete accounts[choice - 1];
                    accounts.erase(accounts.begin() + choice - 1);
                    cout << "Account removed.\n";
                }
                else
                {
                    cout << "Failed to delete account make sure you have an active internet connection.";
                }
            }
        }
        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }

    bool isNumeric(const string &str)
    {
        for (char const &c : str)
        {
            if (isdigit(c) == 0)
                return false;
        }
        return true;
    }

    double getValidatedAmount()
    {
        double amount;
        string input;
        while (true)
        {
            cout << "Enter amount: ";
            cin >> input;
            if (isNumeric(input))
            {
                stringstream ss(input);
                ss >> amount;
                if (amount > 0)
                {
                    break;
                }
                else
                {
                    cout << "Amount should be positive.\n";
                }
            }
            else
            {
                cout << "Invalid amount. Please enter a numeric value.\n";
            }
        }
        return amount;
    }

    string getPasswordInput()
    {
        string password;
        char ch;
        while ((ch = _getch()) != '\r')
        { // '\r' is the Enter key
            if (ch == '\b')
            { // '\b' is the Backspace key
                if (!password.empty())
                {
                    password.pop_back();
                    cout << "\b \b"; // Erase character from console
                }
            }
            else
            {
                password += ch;
                cout << '*'; // Print asterisk instead of character
            }
        }
        cout << endl;
        return password;
    }

    void transferMoney(Account *from_account)
    {
        string recipient_CNIC;
        cout << "Enter recipient's CNIC : ";
        cin >> recipient_CNIC;

        // Check if the recipient CNIC is the same as the sender's CNIC
        if (from_account->getCNIC() == recipient_CNIC)
        {
            cout << "You cannot transfer money to the same account.\n";
            cout << "Press any key to continue...";
            _getch(); // Wait for user input
            return;
        }

        Account *recipient_account = nullptr;
        for (auto account : accounts)
        {
            if (account->getCNIC() == recipient_CNIC)
            {
                recipient_account = account;
                break;
            }
        }

        if (recipient_account)
        {
            double amount = getValidatedAmount();
            cout << "Attempting to withdraw amount: " << amount << " from " << from_account->getUsername() << endl;

            if (from_account->withdraw(amount, "Transfer"))
            {
                cout << "Withdrawal successful. Depositing amount to " << recipient_account->getUsername() << endl;
                recipient_account->deposit(amount, "Received");

                string timestamp = from_account->getCurrentTimestamp();
                cout << "Logging transfer transaction for sender.\n";
                from_account->logTransaction(from_account->getCNIC(), timestamp, "Transfer", amount, recipient_CNIC);

                cout << "Logging transfer transaction for recipient.\n";
                recipient_account->logTransaction(recipient_account->getCNIC(), timestamp, "Received", amount, from_account->getCNIC());

                cout << "Transfer successful.\n";
            }

            else
            {
                cout << "Insufficient balance for transfer.\n";
            }
        }
        else
        {
            cout << "Recipient account not found.\n";
        }
        cout << "Press any key to continue...";
        _getch(); // Wait for user input
    }

    void start()
    {
        while (true)
        {
            system("cls");
            cout << "Welcome to the Bank Management System!\n";
            cout << "1. Login\n2. Create Account\n3. Admin Login\n4. Exit\n";
            int choice;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice)
            {
            case 1:
                login();
                break;
            case 2:
                createAccount();
                break;
            case 3:
                adminLogin();
                break;
            case 4:
                return;
            default:
                cout << "Invalid choice. Please try again.\n";
                _getch(); // Wait for user input
                break;
            }
        }
    }

    void login()
    {
        system("cls");
        string cnic, password;
        cout << "Enter CNIC: ";
        cin >> cnic;
        cout << "Enter password: ";
        password = getPasswordInput();

        PrintColoredText("Logging in...", WaitingMessagesColorCode);
        Account *account = authenticateUser(cnic, password);
        if (account)
        {
            userMenu(account);
        }
        else
        {
            PrintColoredText("Invalid CNIC or password.", ErrorMessagesColorCode);
            cout << "Press any key to continue...";
            _getch(); // Wait for user input
        }
    }

    bool CheckCNIC(string cnic)
    {
        // Assume CNIC is not in use initially
        bool cnicAvailable = true;

        // Check if CNIC already exists in loaded accounts
        for (const auto &account : accounts)
        {
            if (account->getCNIC() == cnic)
            {
                cnicAvailable = false;
                break;
            }
        }

        // Check if CNIC already exists in pending accounts
        if (cnicAvailable)
        {
            for (const auto &account : pendingAccounts)
            {
                if (account->getCNIC() == cnic)
                {
                    cnicAvailable = false;
                    break;
                }
            }
        }
        return cnicAvailable; // Return whether CNIC is available or not
    }
    bool CheckEmail(string email)
    {
        // Assume email is not in use initially
        bool emailAvailable = true;

        // Check if email already exists in loaded accounts
        for (const auto &account : accounts)
        {
            if (account->getEmail() == email)
            {
                emailAvailable = false;
                break;
            }
        }

        // Check if email already exists in pending accounts
        if (emailAvailable)
        {
            for (const auto &account : pendingAccounts)
            {
                if (account->getEmail() == email)
                {
                    emailAvailable = false;
                    break;
                }
            }
        }
        return emailAvailable; // Return whether email is available or not
    }

    void createAccount()
    {
        system("cls");
        string command;
        string cnic, username, password, email, account_type;
        double initial_deposit = 0;

        while (true)
        {
            cout << "Enter CNIC: ";
            cin >> cnic;

            if (cnic.length() != 13)
            {
                PrintColoredText("Invalid CNIC. Please enter a valid 13-digit CNIC including dashes (\"-\").", ErrorMessagesColorCode);
            }
            else if (!CheckCNIC(cnic))
            {
                PrintColoredText("CNIC is already in use. Please enter a different CNIC.", ErrorMessagesColorCode);
            }
            else
            {
                break; // Email is unique, exit the loop
            }
        }

        while (true)
        {
            cout << "Enter username: ";
            cin >> username;
            if (username.length() < 3)
            {
                PrintColoredText("Username must be at least 3 characters", ErrorMessagesColorCode);
            }
            else
            {
                break;
            }
        }

        while (true)
        {
            cout << "Enter password: ";
            cin >> password;
            if (password.length() < 8)
            {
                PrintColoredText("Password must be at least 8 characters", ErrorMessagesColorCode);
            }
            else
            {
                break;
            }
        }

        while (true)
        {
            cout << "Enter email: ";
            cin >> email;

            if (!regex_match(email, regex(".+@.+\\..+")))
            {
                PrintColoredText("Invalid email format. Please enter a valid email.", ErrorMessagesColorCode);
            }
            else if (!CheckEmail(email))
            {
                PrintColoredText("Email is already in use. Please enter a different email.", ErrorMessagesColorCode);
            }
            else
            {
                break; // Email is unique, exit the loop
            }
        }
        while (true)
        {
            cout << "Enter account type (Savings 'S' /Current 'C'): ";
            cin >> account_type;

            if (account_type == "S" || account_type == "s")
            {
                createAccount(new SavingsAccount(cnic, username, password, email, initial_deposit), true);
                break;
            }
            else if (account_type == "C" || account_type == "c")
            {

                createAccount(new CurrentAccount(cnic, username, password, email, initial_deposit), true);
                break;
            }
            else
            {
                PrintColoredText("Invalid account type. Please try again.", ErrorMessagesColorCode);
            }
        }
        PrintColoredText("Hold on we're getting you in.", WaitingMessagesColorCode);
        command = "Register " + username + " " + password + " " + email + " " + account_type + " " + cnic;

        callJavaScript(command);
    }

    void adminLogin()
    {
        system("cls");
        string username, password;
        cout << "Enter admin username: ";
        cin >> username;
        cout << "Enter admin password: ";
        password = getPasswordInput();

        if (authenticateAdmin(username, password))
        {
            adminMenu();
        }
        else
        {
            PrintColoredText("Invalid admin username or password.\n", ErrorMessagesColorCode);
            cout << "Press any key to continue...";
            _getch(); // Wait for user input
        }
    }

    void adminMenu()
    {
        while (true)
        {
            system("cls");
            cout << "Admin Menu\n";
            cout << "1. Approve Pending Accounts\n2. View All Accounts\n3. Remove Account\n4. Logout\n";
            int choice;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice)
            {
            case 1:
                approvePendingAccounts();
                break;
            case 2:
                viewAllAccounts();
                break;
            case 3:
                removeAccount();
                break;
            case 4:
                return;
            default:
                PrintColoredText("Invalid choice. Please try again.\n", ErrorMessagesColorCode);
                _getch(); // Wait for user input
                break;
            }
        }
    }

    void userMenu(Account *account)
    {
        while (true)
        {
            system("cls");
            account->displayMenu();
            int choice;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice)
            {
            case 1:
            {
                double amount = getValidatedAmount();
                account->deposit(amount, "Deposit");
                PrintColoredText("Deposit successful.\n", SuccessMessagesColorCode);
                cout << "Press any key to continue...";
                _getch(); // Wait for user input
                break;
            }
            case 2:
            {
                double amount = getValidatedAmount();
                if (account->withdraw(amount, "Withdrawal"))
                {
                    PrintColoredText("Withdrawal successful.\n", SuccessMessagesColorCode);
                }
                else
                {
                    PrintColoredText("Insufficient balance.\n", ErrorMessagesColorCode);
                }
                cout << "Press any key to continue...";
                _getch(); // Wait for user input
                break;
            }
            case 3:
            {
                while (true)
                {
                    string new_password;
                    cout << "Enter new password: ";
                    cin >> new_password;

                    if (new_password.length() < 8)
                    {
                        PrintColoredText("Password must be at least 8 characters", ErrorMessagesColorCode);
                    }
                    else
                    {
                        changeUserPassword(account->getCNIC(), new_password);
                        break;
                    }
                }
                break;
            }
            case 4:
            {
                while (true)
                {
                    string new_username;
                    cout << "Enter new username: ";
                    cin >> new_username;

                    if (new_username.length() < 3)
                    {
                        PrintColoredText("Username must be at least 3 characters", ErrorMessagesColorCode);
                    }
                    else
                    {
                        changeUserUsername(account->getCNIC(), new_username, account);
                        break;
                    }
                }
                break;
            }
            case 5:
                account->viewTransactionHistory(account->getCNIC());
                break;
            case 6:
                transferMoney(account);
                break;
            case 7:
                return;
            default:
                PrintColoredText("Invalid choice. Please try again.\n", ErrorMessagesColorCode);
                _getch(); // Wait for user input
                break;
            }
        }
    }
};

int main()
{
    if (!checkAndInstallDependencies())
    {
        return 1; // Exit if dependencies are not installed
    }

    setConsoleForegroundColor(DefaultColorCode);
    // Purple=5 Yellow=6 gray=8 lightBlue=9
    Bank bank;

    bank.start();

    return 0;
}
