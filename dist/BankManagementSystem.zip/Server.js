/**
 * Bank Management System
 * ----------------------
 * This script manages user accounts, transactions, and admin operations using Appwrite SDK.
 * 
 * Icons Used:
 * 🔐 - Admin Authentication
 * 🧾 - Fetching Accounts
 * 📛🔑 - Changing User Data [Username & Password]
 * 💰 - Balance Update
 */

// Importing necessary modules from Appwrite SDK
import { Client, Databases, ID, Query } from "appwrite";
import argon2 from 'argon2';

// Constants for project and collection IDs
const PROJECT_ID = "666b2d4b002579cc85ea";
const DATABASE_ID = "666b30e2001dda7640db";
const COLLECTION_ID_USERS = "666caf8d003db35e8a54";
const COLLECTION_ID_TRANSACTIONS = "666dd34e001b637f302a";
const COLLECTION_ID_PENDING_ACCOUNTS = "666efd860025ac6a9e7c";
const COLLECTION_ID_FORGOTPASSWORD_KEYS = "667bfee1002e3534d0f6";
const COLLECTION_ID_ADMIN = "ADMIN";

// Initialize Appwrite client and databases
const client = new Client()
  .setEndpoint("https://cloud.appwrite.io/v1")
  .setProject(PROJECT_ID);
const databases = new Databases(client);

// Extract command line arguments
const args = process.argv.slice(2);
const command = args[0];

/*<=============================================================================================================>
                        !! FUNCTIONS RELATED TO FETCHING ACCOUNTS 🧾 !!                                             
  <=============================================================================================================>
*/


// Fetch accounts based on command line input
if (command === "FetchAccounts") {
  FetchAccounts();
} else if (command === "FetchPendingAccounts") {
  FetchPendingAccounts();
}

/**
 * Fetches user account details from the database and logs them.
 * @returns {void}
 */
async function FetchAccounts() {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_USERS,
      []
    );
    for (let i = 0; i < response.total; i++) {
      const user = response.documents[i];
      const { username, email, accountType, balance, CNIC } = user;

      console.log(
        `${username} ${email} ${accountType} ${balance} ${CNIC}`
      );
    }
  } catch (error) {
    console.error("Error:", error);
  }
}

/**
 * Fetches pending account details from the database and logs specific user information.
 * @returns {void}
 */
async function FetchPendingAccounts() {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_PENDING_ACCOUNTS,
      []
    );
    for (let i = 0; i < response.total; i++) {
      const user = response.documents[i];
      const { username, email, accountType, CNIC } = user;

      console.log(`${username} ${email} ${accountType}  ${CNIC}`);
    }
  } catch (error) {
    console.error("Error:", error);
  }
}

/*<=============================================================================================================>*/

/*<=============================================================================================================>
                        !! MOVING TO ACCOUNTS AFTER ADMIN APPROVAL 🧾 !!                                             
  <=============================================================================================================>
*/

// Move pending account to active status
if (command === "MoveToAccounts") {
  const cnic = args[1];
  MoveToAccounts(cnic);
}

/**
 * Moves a pending account to active status after admin approval.
 * @param {string} username - Username of the account.
 * @param {string} pass - Password of the account.
 * @param {string} email - Email of the account.
 * @param {string} accType - Account type ('Savings' or 'Current').
 * @param {string} cnic - CNIC of the account holder.
 * @returns {void}
 */
async function MoveToAccounts(cnic) {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_PENDING_ACCOUNTS,
      [Query.equal("CNIC", cnic)]
    );
    const { username, email, accountType, CNIC, password, Key } = response.documents[0];
    let payload = {
      username: username,
      password: password,
      email: email,
      accountType: accountType,
      balance: 0,
      CNIC: CNIC,
      Key: Key
    };
    // Create a new user
    const promise = await databases.createDocument(
      DATABASE_ID,
      COLLECTION_ID_USERS,
      ID.unique(),
      payload
    );
    DeleteAccount(cnic, COLLECTION_ID_PENDING_ACCOUNTS);
    console.log("ACCOUNT MOVED TO ACCOUNTS SUCCESSFULLY");
  } catch (error) {
    console.error("Error:", error);
  }
}
/*<=============================================================================================================>*/

/*<=============================================================================================================>
                        !! ADMIN AUTHENTICATION 🔐 !!                                             
  <=============================================================================================================>
*/

// Admin login authentication
if (command === "AdminLogin") {
  const username = args[1];
  const password = args[2];
  AdminLogin(username, password);
}

/**
 * Authenticates admin login credentials.
 * @param {string} username - Admin username.
 * @param {string} password - Admin password.
 * @returns {void}
 */
async function AdminLogin(username, password) {
  try {

    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_ADMIN,
      []
    );
    if (response.documents[0].username === username) {
      const isPasswordValid = await argon2.verify(response.documents[0].password, password);
      if (isPasswordValid) {
        console.log("SUCCESS");
      }
    }
  } catch (error) {
    console.log("Error Occurred");
  }
};

/*<=============================================================================================================>*/

/*<=============================================================================================================>
                        !! USER REGISTRATION 🔐 !!                                             
  <=============================================================================================================>
*/

// Register a new user account
if (command === "Register") {
  const username = args[1];
  const password = args[2];
  const email = args[3];
  const accountType = args[4];
  const cnic = args[5];
  const key = args[6];
  Register(username, password, email, accountType, cnic, key);
}

/**
 * Registers a new user account.
 * @param {string} username - Username for the new account.
 * @param {string} pass - Password for the new account.
 * @param {string} email - Email address of the new account.
 * @param {string} accType - Account type ('S' for Savings or 'C' for Current).
 * @param {string} cnic - CNIC of the new account holder.
 * @param {string} key - key for forgot password of the new account .
 * @returns {void}
 */
async function Register(username, pass, email, accType, cnic, key) {
  try {
    const hashedPassword = await argon2.hash(pass);
    let payload = {
      username: username,
      password: hashedPassword,
      email: email,
      accountType: accType.toUpperCase() === "S" ? "Savings" : "Current",
      balance: 0,
      CNIC: cnic,
      Key: key
    };
    // Create a new user
    const promise = await databases.createDocument(
      DATABASE_ID,
      COLLECTION_ID_PENDING_ACCOUNTS,
      ID.unique(),
      payload
    );
    console.log("USER CREATED SUCCESSFULLY");
  } catch (error) {
    console.error("Error:", error);
  }
}

/*<=============================================================================================================>*/

/*<=============================================================================================================>
                        !! USER LOGIN 🔐 !!                                             
  <=============================================================================================================>
*/
if (command === "UserLogin") {
  const cnic = args[1];
  const password = args[2];
  UserLogin(cnic, password);
}
async function UserLogin(cnic, password) {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_USERS,
      [Query.equal("CNIC", cnic)]
    );
    if (response.documents[0].CNIC === cnic) {
      const isPasswordValid = await argon2.verify(response.documents[0].password, password);
      if (isPasswordValid) {
        console.log("SUCCESS");
      } else {
        console.log("Incorrect password");
      }
    }
  } catch (error) {
    console.log("Error Occurred");
  }
}
/*<=============================================================================================================>*/

/*<=============================================================================================================>
                        !! BALANCE UPDATE 💰 !!                                             
  <=============================================================================================================>
*/

// Update user account balance
if (command === "BalanceUpdate") {
  const cnic = args[1];
  const newBalance = args[2];
  UpdateUserBalance(cnic, newBalance);
}

/**
 * Updates the balance of a user account.
 * @param {string} cnic - CNIC of the user.
 * @param {string} newBalance - New balance to be updated.
 * @returns {void}
 */
async function UpdateUserBalance(cnic, newBalance) {
  let response = await databases.listDocuments(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    [Query.equal("CNIC", cnic)]
  );
  let documentID = response.documents[0].$id;

  let promise = await databases.updateDocument(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    documentID,
    { balance: parseFloat(newBalance) }
  );
}

/*<=============================================================================================================>*/

/*<=============================================================================================================>
                !! CHANGING USER DATA [USERNAME & PASSWORD] 📛🔑 !!                                             
  <=============================================================================================================>
*/

// Change user account password
if (command === "ChangeUserPassword") {
  const cnic = args[1];
  const newPasword = args[2];
  ChangeUserPassword(cnic, newPasword);
}

/**
 * Changes the password of a user account.
 * @param {string} cnic - CNIC of the user.
 * @param {string} newPasword - New password to set for the account.
 * @returns {void}
 */
async function ChangeUserPassword(cnic, newPasword) {
  const hashedPassword = await argon2.hash(newPasword);
  let response = await databases.listDocuments(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    [Query.equal("CNIC", cnic)]
  );
  let documentID = response.documents[0].$id;

  let promise = await databases.updateDocument(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    documentID,
    { password: hashedPassword }
  );
}

// Change user account username
if (command === "ChangeUserUsername") {
  const cnic = args[1];
  const newUsername = args[2];
  ChangeUserUsername(cnic, newUsername);
}

/**
 * Changes the username of a user account.
 * @param {string} cnic - CNIC of the user.
 * @param {string} newUsername - New username to set for the account.
 * @returns {void}
 */
async function ChangeUserUsername(cnic, newUsername) {
  let response = await databases.listDocuments(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    [Query.equal("CNIC", cnic)]
  );
  let documentID = response.documents[0].$id;

  let promise = await databases.updateDocument(
    DATABASE_ID,
    COLLECTION_ID_USERS,
    documentID,
    { username: newUsername }
  );
  console.log("USERNAME_UPDATED");
}

/*<=============================================================================================================>*/

/*<=============================================================================================================>
                !! LOG TRANSACTION IN THE DATABASE  !!                                             
  <=============================================================================================================>
*/

// Log transaction in the database
if (command === "LogTransaction") {
  const cnic = args[1];
  const timestamp = args[2];
  const type = args[3];
  const amount = parseFloat(args[4]);
  if (args[5]) {
    const ToORFromCNIC = args[5];
    logTransaction(cnic, timestamp, type, amount, ToORFromCNIC);
  } else {
    logTransaction(cnic, timestamp, type, amount);
  }
}

/**
 * Logs a transaction into the transactions database.
 * @param {string} cnic - CNIC of the user.
 * @param {string} timestamp - Timestamp of the transaction.
 * @param {string} type - Type of transaction ('Received', 'Sent', 'Transfer').
 * @param {number} amount - Amount of money involved in the transaction.
 * @param {string} [ToORFromCNIC] - CNIC of the recipient or sender in case of 'Transfer'.
 * @returns {void}
 */
async function logTransaction(cnic, timestamp, type, amount, ToORFromCNIC) {
  try {
    const payload = {
      cnic: cnic,
      timestamp: timestamp,
      type: type,
      amount: amount,
      ToORFromCNIC: ToORFromCNIC,
    };
    await databases.createDocument(
      DATABASE_ID,
      COLLECTION_ID_TRANSACTIONS,
      ID.unique(),
      payload
    );
    console.log("TRANSACTION_LOGGED");
  } catch (error) {
    console.error(error);
  }
}

// Fetch user transactions from the database
if (command === "FetchTransactions") {
  const cnic = args[1];
  fetchTransactions(cnic);
}

/**
 * Fetches user transactions from the transactions database.
 * @param {string} cnic - CNIC of the user.
 * @returns {void}
 */
async function fetchTransactions(cnic) {
  try {
    const response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_TRANSACTIONS,
      [Query.equal("cnic", cnic)]
    );
    let transactions = response.documents.map((doc) => ({
      CNIC: doc.cnic,
      Timestamp: doc.timestamp,
      Type: doc.type,
      Amount: `$${doc.amount}`,
      "From(CNIC)": doc.type === "Received" && doc.ToORFromCNIC ? doc.ToORFromCNIC : "",
      "To(CNIC)": doc.type === "Transfer" && doc.ToORFromCNIC ? doc.ToORFromCNIC : ""
    }));
    // Check if any "From(CNIC)" or "To(CNIC)" fields have values
    const includeFrom = transactions.some(transaction => transaction["From(CNIC)"]);
    const includeTo = transactions.some(transaction => transaction["To(CNIC)"]);

    // Filter out empty fields
    transactions = transactions.map(transaction => {
      const filteredTransaction = { ...transaction };
      if (!includeFrom) delete filteredTransaction["From(CNIC)"];
      if (!includeTo) delete filteredTransaction["To(CNIC)"];
      return filteredTransaction;
    });
    // Calculate column widths
    const columns = ["CNIC", "Timestamp", "Type", "Amount"];
    if (includeFrom) columns.push("From(CNIC)");
    if (includeTo) columns.push("To(CNIC)");

    const colWidths = columns.map(col => col.length);
    transactions.forEach(transaction => {
      columns.forEach((col, i) => {
        colWidths[i] = Math.max(colWidths[i], (transaction[col] || "").toString().length);
      });
    });

    // Create the table header
    const separator = colWidths.map(width => '-'.repeat(width + 2.1)).join('+');
    const header = columns.map((col, i) => col.padEnd(colWidths[i])).join(' | ');

    // Print the table
    console.log(` ${separator}`);
    console.log(` | ${header} |`);
    console.log(` ${separator}`);
    transactions.forEach(transaction => {
      const row = columns.map((col, i) => (transaction[col] || "").toString().padEnd(colWidths[i])).join(' | ');
      console.log(` | ${row} |`);
    });
    console.log(` ${separator}`);
  } catch (error) {
    console.error(error);
  }
}

// Delete user account from the database
if (command === "DeleteAccount") {
  const cnic = args[1];
  DeleteAccount(cnic, COLLECTION_ID_USERS);
}

/**
 * Deletes a user account from the database.
 * @param {string} cnic - CNIC of the user.
 * @param {string} CollectionID - ID of the collection from which the account will be deleted.
 * @returns {void}
 */
async function DeleteAccount(cnic, CollectionID) {
  try {
    let response = await databases.listDocuments(DATABASE_ID, CollectionID, [
      Query.equal("CNIC", cnic),
    ]);
    let documentID = response.documents[0].$id;

    let promise = await databases.deleteDocument(
      DATABASE_ID,
      CollectionID,
      documentID
    );

    /* The below code is using JavaScript to list documents from a database collection based on a
    specific query (in this case, querying for documents where the "cnic" field is equal to a
    certain value). It then iterates over the resulting documents and deletes each document from the
    database collection one by one. The code uses asynchronous functions and awaits the completion
    of each operation before moving on to the next one. */
    let res = await databases.listDocuments(DATABASE_ID, COLLECTION_ID_TRANSACTIONS, [
      Query.equal("cnic", cnic),
    ]);

    res.documents.forEach(async (doc) => {
      let promise = await databases.deleteDocument(
        DATABASE_ID,
        COLLECTION_ID_TRANSACTIONS,
        doc.$id
      );
    })
    console.log("ACCOUNT_DELETED");
  } catch (error) {
    console.error("Error:", error);
  }
}

if (command === "forgot_password") {
  const cnic = args[1];
  const key = args[2];

  forgot_password(cnic, key);
}
async function forgot_password(cnic, key) {
  try {
    let response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID_USERS,
      [Query.equal("CNIC", cnic), Query.equal("Key", key)]
    );
    if (response.total > 0) {
      console.log("SUCCESS");
    }

  } catch (e) {
    console.log("ERROR ");
  }
}

